# K.A.J StudyIA — página pública de apresentação

Este pacote contém APENAS uma página estática de apresentação para GitHub Pages.

Ele NÃO contém `app.py`, chave de API, banco de dados, contas ou código do servidor. Não acrescente esses arquivos ao repositório público.

## Arquivos
- `index.html` — página inicial de apresentação.
- `static/images/` — imagens públicas usadas na página.

## Publicar com GitHub Pages
1. Com a orientação de um responsável, entre no GitHub.
2. Crie um repositório público chamado `kaj-studyia-apresentacao`.
3. Use **Add file → Upload files** e envie o conteúdo desta pasta (o `index.html` precisa ficar na raiz do repositório e a pasta `static` ao lado).
4. Abra **Settings → Pages**.
5. Em **Build and deployment**, escolha **Deploy from a branch**.
6. Selecione a branch `main` e a pasta `/ (root)`, depois clique em **Save**.
7. O GitHub Pages mostrará a URL pública do site na própria tela de Pages.

A URL ficará no formato `https://SEU-USUARIO.github.io/kaj-studyia-apresentacao/`.

## Limitações importantes
GitHub Pages hospeda arquivos estáticos (HTML, CSS, JavaScript e imagens). Ele NÃO executa Flask/Python, não hospeda a API e não oferece banco de dados para esta aplicação. Esta página foi ajustada para deixar isso claro e não aponta para o endereço local `127.0.0.1`.

Não use esta página como prova de que o aplicativo está disponível para compradores. Antes de vender acesso, hospede o backend separadamente com armazenamento persistente e revise autenticação, proteção contra abuso, privacidade/LGPD, segurança de menores e custos de API.
